<?php

class Config {

    const DEVELOPMENT_URL = 'http://localhost:8888/login';

    const PRODUCTION_URL = 'http://edwincodecollege.com/login_app';

    const SMTP_HOST = 'smtp.mailtrap.io';

    const SMTP_USER = 'd455be5b5ef677';

    const SMTP_PASSWORD = '223b3cb4312524';

    const SMTP_PORT = 2525;


}
