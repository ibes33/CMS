<?php


phpinfo();



?>